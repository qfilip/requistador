﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Pipeline.Mediator;
using System.Threading.Tasks;

namespace Pipeline
{
    [Route("api")]
    public class ApiController : ControllerBase
    {
        private readonly IMediator mediator;
        public ApiController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [Route("get")]
        [HttpGet]
        public async Task Get()
        {
            await this.mediator.Send(new SomeCommand());
        }
    }
}
