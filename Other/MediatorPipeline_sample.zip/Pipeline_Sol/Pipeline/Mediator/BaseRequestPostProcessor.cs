﻿using MediatR;
using MediatR.Pipeline;
using System.Threading;
using System.Threading.Tasks;

namespace Pipeline.Mediator
{
    public class BaseRequestPostProcessor<TRequest, TResponse> : IRequestPostProcessor<TRequest, TResponse>
        where TRequest : IRequest<TResponse>
    {
        public async Task Process(TRequest request, TResponse response, CancellationToken cancellationToken)
        {
            var x = 0;
            await Task.FromResult(false);
        }
    }
}
