﻿using MediatR.Pipeline;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Pipeline.Mediator
{
    public class BaseExceptionAction<TRequest, TException> : IRequestExceptionAction<TRequest, TException>
        where TException : Exception
    {
        public async Task Execute(TRequest request, TException exception, CancellationToken cancellationToken)
        {
            var x = 0;
            await Task.FromResult("I handled it");
        }
    }
}
