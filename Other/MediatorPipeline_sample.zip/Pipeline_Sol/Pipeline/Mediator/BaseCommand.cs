﻿using MediatR;

namespace Pipeline.Mediator
{
    public abstract class BaseCommand<TDto> :IRequest<TDto>
    {
    }
}
