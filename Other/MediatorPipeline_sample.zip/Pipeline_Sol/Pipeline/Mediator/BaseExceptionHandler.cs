﻿using MediatR;
using MediatR.Pipeline;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Pipeline.Mediator
{
    public class BaseExceptionHandler<TRequest, TResponse> : IRequestExceptionHandler<TRequest, TResponse>
        where TRequest : IRequest<TResponse>
    {
        public async Task Handle(TRequest request, Exception exception, RequestExceptionHandlerState<TResponse> state, CancellationToken cancellationToken)
        {
            Console.WriteLine("I can handle exceptions, yay");
            var x = 0;
            
            await Task.FromResult(false);
        }
    }
}
