﻿using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Pipeline.Mediator
{
    public abstract class BaseHandler<TCommand, TResponse> : IRequestHandler<TCommand, TResponse>
        where TCommand : IRequest<TResponse>
    {
        public abstract Task<TResponse> Handle(TCommand request, CancellationToken cancellationToken);
    }
}
