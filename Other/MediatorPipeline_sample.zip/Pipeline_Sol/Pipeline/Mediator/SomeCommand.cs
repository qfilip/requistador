﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Pipeline.Mediator
{
    public class SomeCommand : BaseCommand<Object>
    {
        public SomeCommand()
        {

        }

        public class Handler : BaseHandler<SomeCommand, Object>
        {
            public async override Task<object> Handle(SomeCommand request, CancellationToken cancellationToken)
            {
                var y = 0;
                throw new Exception();
                return await Task.FromResult(new Object());
            }
        }
    }
}
