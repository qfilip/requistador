﻿using MediatR.Pipeline;
using System.Threading;
using System.Threading.Tasks;

namespace Pipeline.Mediator
{
    public class BaseRequestPreProcessor<TRequest> : IRequestPreProcessor<TRequest>
    {
        public async Task Process(TRequest request, CancellationToken cancellationToken)
        {
            await Task.FromResult(false);
        }
    }
}
